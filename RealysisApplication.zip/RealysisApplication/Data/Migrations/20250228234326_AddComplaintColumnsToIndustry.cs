﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RealysisApplication.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddComplaintColumnsToIndustry : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Complaint1",
                table: "Industries",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Complaint2",
                table: "Industries",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Complaint3",
                table: "Industries",
                type: "nvarchar(max)",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Complaint1",
                table: "Industries");

            migrationBuilder.DropColumn(
                name: "Complaint2",
                table: "Industries");

            migrationBuilder.DropColumn(
                name: "Complaint3",
                table: "Industries");
        }
    }
}
