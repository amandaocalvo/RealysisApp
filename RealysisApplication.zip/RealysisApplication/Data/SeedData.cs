﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using RealysisApplication.Models;
using System;
using System.Linq;

namespace RealysisApplication.Data
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new ApplicationDbContext(
                serviceProvider.GetRequiredService<DbContextOptions<ApplicationDbContext>>()))
            {
                // Define the seed data
                var industriesToSeed = new Industry[]
                {
                    new Industry
                    {
                        Name = "Technology",
                        Complaint1 = "Poor customer support or long wait times",
                        Complaint2 = "Software bugs or glitches",
                        Complaint3 = "High costs for updates or subscriptions"
                    },
                    new Industry
                    {
                        Name = "Healthcare",
                        Complaint1 = "Long wait times for appointments",
                        Complaint2 = "High medical bills or hidden fees",
                        Complaint3 = "Poor communication from healthcare providers"
                    },
                    new Industry
                    {
                        Name = "Finance",
                        Complaint1 = "Hidden fees or unclear charges",
                        Complaint2 = "Slow processing of transactions or claims",
                        Complaint3 = "Poor customer service or lack of responsiveness"
                    },
                    new Industry
                    {
                        Name = "Retail",
                        Complaint1 = "Poor product quality or defects",
                        Complaint2 = "Shipping delays or lost orders",
                        Complaint3 = "Difficult return or refund process"
                    },
                    new Industry
                    {
                        Name = "Energy",
                        Complaint1 = "High utility bills or unexplained charges",
                        Complaint2 = "Frequent outages or interruptions in service",
                        Complaint3 = "Poor customer service or difficulty resolving issues"
                    },
                    new Industry
                    {
                        Name = "Real Estate",
                        Complaint1 = "Hidden costs or fees in contracts",
                        Complaint2 = "Misleading property listings or descriptions",
                        Complaint3 = "Poor communication from agents or agencies"
                    },
                    new Industry
                    {
                        Name = "Automotive",
                        Complaint1 = "Poor vehicle performance or defects",
                        Complaint2 = "High repair costs or difficult warranty claims",
                        Complaint3 = "Long service wait times or poor customer service"
                    },
                    new Industry
                    {
                        Name = "Entertainment & Media",
                        Complaint1 = "Poor content availability or selection",
                        Complaint2 = "High subscription fees or unexpected price hikes",
                        Complaint3 = "Poor streaming quality or technical issues"
                    },
                    new Industry
                    {
                        Name = "Manufacturing",
                        Complaint1 = "Delays in product delivery",
                        Complaint2 = "Low product quality or defects",
                        Complaint3 = "Poor after-sales service or lack of support"
                    },
                    new Industry
                    {
                        Name = "Food & Beverage",
                        Complaint1 = "Poor food quality or inconsistency",
                        Complaint2 = "Long wait times or slow service",
                        Complaint3 = "Incorrect orders or missing items"
                    }
                };

                foreach (var seedIndustry in industriesToSeed)
                {
                    // Check if the industry exists by Name
                    var industry = context.Industries.FirstOrDefault(i => i.Name == seedIndustry.Name);
                    if (industry == null)
                    {
                        // If it doesn't exist, add it
                        context.Industries.Add(seedIndustry);
                    }
                    else
                    {
                        // If it exists, update the complaint fields
                        industry.Complaint1 = seedIndustry.Complaint1;
                        industry.Complaint2 = seedIndustry.Complaint2;
                        industry.Complaint3 = seedIndustry.Complaint3;
                    }
                }
                context.SaveChanges();
            }
        }
    }
}
