﻿using System.ComponentModel.DataAnnotations;

namespace RealysisApplication.Models
{
    public class Industry
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Industry Name")]
        public string? Name { get; set; }
        public string? Complaint1 { get; set; }
        public string? Complaint2 { get; set; }
        public string? Complaint3 { get; set; }
    }
}
