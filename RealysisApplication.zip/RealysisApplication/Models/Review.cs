﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Identity;

namespace RealysisApplication.Models
{
    public class Review
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Customer Review")]
        public string? Content { get; set; }

        // Link the review to an Identity user (the AspNetUsers table)
        [Required]
        public string? UserId { get; set; }

        [ForeignKey("UserId")]
        public virtual IdentityUser? User { get; set; }
    }
}
