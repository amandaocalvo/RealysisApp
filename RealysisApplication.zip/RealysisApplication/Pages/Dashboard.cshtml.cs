using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RealysisApplication.Data;
using RealysisApplication.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RealysisApplication.Pages
{
    public class DashboardModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        public DashboardModel(ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty(SupportsGet = true)]
        public string? SelectedIndustry { get; set; }

        public List<Industry> IndustryData { get; set; } = new List<Industry>();

        public IEnumerable<SelectListItem>? Industries { get; set; }

        public async Task OnGetAsync(string sortOrder, int? page)
        {
            // Build the dropdown list from the Industries table
            var industriesList = await _context.Industries
                .Select(i => i.Name)
                .Distinct()
                .ToListAsync();

            Industries = industriesList.Select(i => new SelectListItem
            {
                Value = i,
                Text = i
            });

            // Filter data based on selected industry
            var query = _context.Industries.AsQueryable();
            if (!string.IsNullOrEmpty(SelectedIndustry))
            {
                query = query.Where(i => i.Name == SelectedIndustry);
            }

            // Example sorting by Name (toggle sortOrder parameter as needed)
            query = string.IsNullOrEmpty(sortOrder)
                ? query.OrderBy(i => i.Name)
                : query.OrderByDescending(i => i.Name);

            // Example paging
            int pageSize = 10;
            int pageNumber = page ?? 1;
            IndustryData = await query
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();
        }
    }
}
