﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RealysisApplication.Data;
using RealysisApplication.Models;
using Microsoft.AspNetCore.Identity;

namespace RealysisApplication.Pages.Reviews
{

    [Authorize]
    public class IndexModel : PageModel
    {
        private readonly RealysisApplication.Data.ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;

        public IndexModel(RealysisApplication.Data.ApplicationDbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public IList<Review> Review { get;set; } = default!;

        public async Task OnGetAsync()
        {
            // Retrieve the current logged-in user
            var currentUser = await _userManager.GetUserAsync(User);
            if (currentUser == null)
            {
                // Optional: Handle the case if currentUser is null (shouldn't happen with [Authorize])
                return;
            }

            // Filter reviews to show only those belonging to the current user
            Review = await _context.Reviews
                         .Where(r => r.UserId == currentUser.Id)
                         .Include(r => r.User)
                         .ToListAsync();
        }




    }
}
