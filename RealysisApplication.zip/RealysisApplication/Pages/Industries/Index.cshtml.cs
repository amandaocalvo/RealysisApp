﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RealysisApplication.Data;
using RealysisApplication.Models;

namespace RealysisApplication.Pages.Industries
{
    [Authorize]
    public class IndexModel : PageModel
    {
        private readonly RealysisApplication.Data.ApplicationDbContext _context;

        public IndexModel(RealysisApplication.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Industry> Industry { get;set; } = default!;

        public async Task OnGetAsync()
        {
            if (_context.Industries != null)
            {
                Industry = await _context.Industries.ToListAsync();
            }
        }
    }
}
