using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RealysisApplication.Data;
using RealysisApplication.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Authorization;
using System.IO;
using System.Threading.Tasks;

namespace RealysisApplication.Pages
{
    [Authorize]
    public class UploadReviewsModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;

        public UploadReviewsModel(ApplicationDbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        [BindProperty]
        public IFormFile? SpreadsheetFile { get; set; }







        public async Task<IActionResult> OnPostAsync()
        {
            if (SpreadsheetFile == null || SpreadsheetFile.Length == 0)
            {
                ModelState.AddModelError("", "Please upload a valid file.");
                return Page();
            }

            using (var stream = new MemoryStream())
            {
                await SpreadsheetFile.CopyToAsync(stream);
                stream.Position = 0;

                // Retrieve the current user
                var currentUser = await _userManager.GetUserAsync(User);
                if (currentUser == null)
                {
                    // If the user is null, redirect to the login page (or handle appropriately)
                    return RedirectToPage("/Identity/Account/Login");
                }

                // Now it's safe to access currentUser.Id
                for (int i = 0; i < 30; i++)
                {
                    var review = new Review
                    {
                        Content = $"Review {i + 1} extracted from spreadsheet",
                        UserId = currentUser.Id
                    };
                    _context.Reviews.Add(review);
                }
                await _context.SaveChangesAsync();
            }

            // After processing, redirect to the Dashboard page.
            return RedirectToPage("/Dashboard");
        }







    }
}
